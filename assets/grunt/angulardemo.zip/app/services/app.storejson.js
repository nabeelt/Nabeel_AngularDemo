// app.service('newService',['$http',
// 	function($http){
// 		var categoryJSON =[];
// 		this.getData = function(){
// 			return $http.get(categoryJSON);
// 		}
	
// }]);