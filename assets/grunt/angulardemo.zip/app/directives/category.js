app.directive("category",function(){
		return{
			restrict:"E",
			templateUrl : "app/views/category.html",
		}
	});
