module.exports = function(grunt){
	grunt.initConfig({
		min:{
			dist:{
				src:'addCategory.js',
				dest:'addCategory.min.js'
			}
		}
	})
} 